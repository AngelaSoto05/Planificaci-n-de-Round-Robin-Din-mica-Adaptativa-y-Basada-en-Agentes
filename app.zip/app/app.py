import sys
import os
from time import time
from flask import Flask, render_template, request, session, redirect, url_for

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from aadrr import aadrr_scheduler
from compare_algorithms import fcfs_scheduler, round_robin_scheduler
from visualize import generate_gantt_chart, generate_comparison_chart

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Needed for session

SCHEDULERS = {
    "AADRR": aadrr_scheduler,
    "FCFS": fcfs_scheduler,
    "RR": lambda p: round_robin_scheduler(p, time_quantum=4)
}

@app.route("/", methods=["GET"])
def home():
    return render_template("home.html")

# 🔹 Page 1: Only AADRR result
@app.route("/aadrr_result", methods=["POST"])
def aadrr_result():
    pids = request.form.getlist("pid[]")
    arrivals = request.form.getlist("arrival[]")
    bursts = request.form.getlist("burst[]")
    priorities = request.form.getlist("priority[]")

    processes = []
    for i in range(len(pids)):
        try:
            if not (pids[i] and arrivals[i] and bursts[i] and priorities[i]):
                continue
            processes.append({
                "pid": pids[i],
                "arrival": int(arrivals[i]),
                "burst": int(bursts[i]),
                "priority": int(priorities[i])
            })
        except ValueError:
            continue

    session["process_data"] = processes  # Store for later use in comparison

    proc_copy = [p.copy() for p in processes]
    timeline, completed, dtq_log, agent_log = aadrr_scheduler(proc_copy)

    # Calculate TAT, WT, RT
    pid_map = {p["pid"]: p for p in processes}
    first_starts = {}
    for slot in timeline:
        pid = slot["pid"]
        if pid not in first_starts:
            first_starts[pid] = slot["start"]

    total_tat = total_wt = total_rt = 0
    results = []
    for c in completed:
        pid = c["pid"]
        end = c["end_time"]
        arrival = pid_map[pid]["arrival"]
        burst = pid_map[pid]["burst"]
        tat = end - arrival
        wt = max(0, tat - burst)
        rt = first_starts.get(pid, arrival) - arrival  # RT = first start - arrival
        results.append({
            "pid": pid,
            "arrival": arrival,
            "burst": burst,
            "completion": end,
            "tat": tat,
            "wt": wt,
            "rt": rt
        })
        total_tat += tat
        total_wt += wt
        total_rt += rt

    avg_tat = round(total_tat / len(results), 2)
    avg_wt = round(total_wt / len(results), 2)
    avg_rt = round(total_rt / len(results), 2)

    # Generate Gantt chart
    chart_name = f"gantt_chart_{int(time())}.png"
    chart_path = os.path.join("static", chart_name)
    generate_gantt_chart(timeline, filename=chart_path)

    aadrr_result = {
        "results": results,
        "timeline": timeline,
        "avg_tat": avg_tat,
        "avg_wt": avg_wt,
        "avg_rt": avg_rt,
        "dtq": dtq_log,
        "agent_log": agent_log,
        "gantt_filename": chart_name
    }

    return render_template("aadrr_result.html", aadrr=aadrr_result)

# 🔹 Page 2: Comparison (uses session data)
@app.route("/comparison", methods=["GET"])
def comparison():
    processes = session.get("process_data")
    if not processes:
        return redirect(url_for("home"))

    all_results = {}

    for name, scheduler in SCHEDULERS.items():
        proc_copy = [p.copy() for p in processes]

        if name == "AADRR":
            timeline, completed, dtq_log, agent_log = scheduler(proc_copy)
        else:
            timeline, completed = scheduler(proc_copy)

        pid_map = {p["pid"]: p for p in processes}
        first_starts = {}
        for slot in timeline:
            pid = slot["pid"]
            if pid not in first_starts:
                first_starts[pid] = slot["start"]

        result_list = []
        total_tat = total_wt = total_rt = 0

        for c in completed:
            pid = c["pid"]
            end = c["end_time"]
            arrival = pid_map[pid]["arrival"]
            burst = pid_map[pid]["burst"]
            tat = end - arrival
            wt = max(0, tat - burst)
            rt = first_starts.get(pid, arrival) - arrival
            result_list.append({
                "pid": pid,
                "arrival": arrival,
                "burst": burst,
                "completion": end,
                "tat": tat,
                "wt": wt,
                "rt": rt
            })
            total_tat += tat
            total_wt += wt
            total_rt += rt

        avg_tat = round(total_tat / len(result_list), 2)
        avg_wt = round(total_wt / len(result_list), 2)
        avg_rt = round(total_rt / len(result_list), 2)

        all_results[name] = {
            "avg_tat": avg_tat,
            "avg_wt": avg_wt,
            "avg_rt": avg_rt,
            "results": result_list
        }

    # Generate comparison chart
    chart_file = f"static/comparison_chart_{int(time())}.png"
    generate_comparison_chart(all_results, filename=chart_file)

    summary_only = {
        k: {"avg_tat": v["avg_tat"], "avg_wt": v["avg_wt"], "avg_rt": v["avg_rt"]}
        for k, v in all_results.items()
    }

    return render_template("comparison.html",
                           results=summary_only,
                           all_results=all_results,
                           chart_file=chart_file)

if __name__ == "__main__":
    app.run(debug=True)
